
import { Task, TaskStatus, User, UserRole } from './types';

// আপনার হোয়াটসঅ্যাপ নাম্বারটি এখানে দিন
export const WHATSAPP_NUMBER = '8801816673208'; 

// প্রতি ১টি কাজের রেট
export const BASE_REWARD_RATE = 0.38;

export const INITIAL_USER: User = {
  id: 'S-1001',
  name: 'Demo Member',
  role: UserRole.MEMBER,
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix',
  balance: 0,
  totalEarned: 0,
  joinedDate: new Date().toISOString()
};

export const MOCK_TASKS: Task[] = [
  {
    id: 'WV-101',
    title: 'Daily Traffic Task',
    description: 'Earn ৳0.38 per valid website visit tracking.',
    rewardAmount: BASE_REWARD_RATE,
    // Fix: Added missing properties to satisfy Task interface as per error on line 21
    status: TaskStatus.OPEN,
    createdAt: new Date().toISOString(),
    guidelines: [
      'Stay on the page for at least 60 seconds.',
      'Click on at least one internal post.',
      'Provide valid proof of visit via WhatsApp.',
      'Genuine traffic only, no VPN/Proxy usage.'
    ]
  }
];
