
import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import TaskSubmission from './components/TaskSubmission';
import AdminPanel from './components/AdminPanel';
import Payouts from './components/Payouts';
import Login from './components/Login';
import { Task, Report, User, TaskStatus, PayoutRequest, PayoutStatus, UserRole } from './types';
import { MOCK_TASKS } from './constants';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS);
  const [reports, setReports] = useState<Report[]>([]);
  const [payouts, setPayouts] = useState<PayoutRequest[]>([]);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isAppLoading, setIsAppLoading] = useState(true);

  // Load initial data and check session
  useEffect(() => {
    const savedUsers = localStorage.getItem('tf_users');
    const savedReports = localStorage.getItem('tf_reports');
    const savedPayouts = localStorage.getItem('tf_payouts');
    const savedTasks = localStorage.getItem('tf_tasks');
    const savedSession = localStorage.getItem('tf_session');

    if (savedUsers) setAllUsers(JSON.parse(savedUsers));
    if (savedReports) setReports(JSON.parse(savedReports));
    if (savedPayouts) setPayouts(JSON.parse(savedPayouts));
    if (savedTasks) setTasks(JSON.parse(savedTasks));
    
    if (savedSession) {
      setCurrentUser(JSON.parse(savedSession));
    }
    
    setIsAppLoading(false);
  }, []);

  // Strict Tab Security Guard & Path Fixer
  useEffect(() => {
    if (currentUser && currentUser.role === UserRole.MEMBER && activeTab === 'admin') {
      setActiveTab('dashboard');
    }
    
    // If user is on a broken path (simulated by some environments), reset to dashboard
    if (window.location.pathname !== '/' && window.location.pathname !== '') {
       // We don't use window.location.replace to avoid infinite loops in some sandboxes
       // but we ensure the 'activeTab' stays visible.
    }
  }, [activeTab, currentUser]);

  // Persist data when state changes
  useEffect(() => {
    if (!isAppLoading) {
      if (allUsers.length > 0) {
        localStorage.setItem('tf_users', JSON.stringify(allUsers));
      }
      localStorage.setItem('tf_reports', JSON.stringify(reports));
      localStorage.setItem('tf_payouts', JSON.stringify(payouts));
      localStorage.setItem('tf_tasks', JSON.stringify(tasks));
      
      if (currentUser) {
        localStorage.setItem('tf_session', JSON.stringify(currentUser));
      } else {
        localStorage.removeItem('tf_session');
      }
    }
  }, [allUsers, reports, payouts, tasks, currentUser, isAppLoading]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setAllUsers(prev => {
      const exists = prev.find(u => u.id === user.id);
      if (!exists && user.role !== UserRole.ADMIN) {
        return [...prev, user];
      }
      return prev;
    });
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('tf_session');
    setActiveTab('dashboard');
  };

  const handleAddTask = (task: Task) => setTasks(prev => [task, ...prev]);

  const handleSubmitReport = (reportData: any) => {
    if (!currentUser) return;
    const task = tasks.find(t => t.id === reportData.taskId);
    const newReport: Report = {
      id: 'r' + Math.random().toString(36).substr(2, 9),
      taskId: reportData.taskId,
      userId: currentUser.id,
      taskTitle: task?.title || 'Unknown Campaign',
      submissionDate: new Date().toISOString(),
      workerName: reportData.workerName,
      workLink: reportData.workLink,
      visitCount: reportData.visitCount,
      workDate: reportData.workDate,
      notes: reportData.notes,
      status: TaskStatus.PENDING_VERIFICATION
    };
    setReports(prev => [newReport, ...prev]);
    setActiveTab('reports');
  };

  const handleVerifyReport = (reportId: string, status: TaskStatus) => {
    const report = reports.find(r => r.id === reportId);
    if (!report) return;
    
    setReports(prev => prev.map(r => r.id === reportId ? { ...r, status } : r));
    
    if (status === TaskStatus.COMPLETED) {
      const task = tasks.find(t => t.id === report.taskId);
      const reward = (task?.rewardAmount || 0) * (report.visitCount || 1);
      
      setAllUsers(prev => prev.map(u => u.id === report.userId ? { ...u, balance: u.balance + reward, totalEarned: u.totalEarned + reward } : u));
      if (currentUser && currentUser.id === report.userId) {
        setCurrentUser(prev => prev ? { ...prev, balance: prev.balance + reward, totalEarned: prev.totalEarned + reward } : null);
      }
    }
  };

  const handleRequestPayout = (data: { amount: number, method: string, accountDetails: string }) => {
    if (!currentUser) return;
    const newPayout: PayoutRequest = {
      id: 'p' + Math.random().toString(36).substr(2, 9),
      userId: currentUser.id, userName: currentUser.name, amount: data.amount,
      requestDate: new Date().toISOString(), status: PayoutStatus.PENDING,
      method: data.method, accountDetails: data.accountDetails
    };
    setPayouts(prev => [newPayout, ...prev]);
    setAllUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, balance: u.balance - data.amount } : u));
    setCurrentUser(prev => prev ? { ...prev, balance: prev.balance - data.amount } : null);
  };

  const handleManagePayout = (payoutId: string, status: PayoutStatus) => {
    setPayouts(prev => prev.map(p => p.id === payoutId ? { ...p, status } : p));
  };

  if (isAppLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!currentUser) {
    return <Login onLogin={handleLogin} existingUsers={allUsers} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row">
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} role={currentUser.role} />
      
      <main className="flex-1 lg:ml-64 p-6 md:p-12 pb-24 lg:pb-12 overflow-y-auto">
        <div className="flex justify-between items-center mb-8">
          <div className="lg:hidden flex items-center gap-3">
             <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white text-xs">
                <i className="fa-solid fa-bolt"></i>
             </div>
             <span className="font-black text-slate-900 tracking-tighter uppercase">TASKFLOW</span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-xs font-black text-slate-900">{currentUser.name}</span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">ID: {currentUser.id}</span>
            </div>
            <button 
              onClick={handleLogout} 
              className="text-[10px] font-black uppercase text-slate-400 hover:text-rose-500 transition-colors flex items-center gap-2 bg-white px-4 py-2 rounded-xl shadow-sm border border-slate-100"
            >
              <i className="fa-solid fa-right-from-bracket"></i> Logout
            </button>
          </div>
        </div>

        {activeTab === 'dashboard' && (
          <Dashboard 
            tasks={tasks} 
            reports={reports.filter(r => r.userId === currentUser.id)} 
            user={currentUser} 
            onNavigateToSubmit={() => setActiveTab('submit')}
            onNavigateToWithdraw={() => setActiveTab('payouts')}
          />
        )}

        {activeTab === 'submit' && (
          <TaskSubmission 
            activeCampaigns={tasks.filter(t => t.status === TaskStatus.OPEN)} 
            onCancel={() => setActiveTab('dashboard')} 
            onSubmit={handleSubmitReport} 
          />
        )}

        {activeTab === 'reports' && (
          <div className="space-y-6 animate-fadeIn max-w-5xl mx-auto">
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">Report History</h2>
            <div className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase font-bold tracking-wider">
                    <tr>
                      <th className="px-6 py-4">Date</th>
                      <th className="px-6 py-4">Campaign</th>
                      <th className="px-6 py-4">Visits</th>
                      <th className="px-6 py-4 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {reports.filter(r => r.userId === currentUser.id).length === 0 ? (
                       <tr>
                         <td colSpan={4} className="px-6 py-12 text-center text-slate-400 font-bold">No reports submitted yet.</td>
                       </tr>
                    ) : (
                      reports.filter(r => r.userId === currentUser.id).map(r => (
                        <tr key={r.id} className="hover:bg-slate-50/50">
                          <td className="px-6 py-4 text-xs font-medium text-slate-500">{r.workDate}</td>
                          <td className="px-6 py-4 text-xs font-black text-slate-900">{r.taskTitle}</td>
                          <td className="px-6 py-4 text-xs font-black text-emerald-600">{r.visitCount}</td>
                          <td className="px-6 py-4 text-right">
                            <span className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider ${
                              r.status === TaskStatus.COMPLETED ? 'bg-emerald-50 text-emerald-600' : 
                              r.status === TaskStatus.PENDING_VERIFICATION ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'
                            }`}>
                              {r.status === TaskStatus.PENDING_VERIFICATION ? 'Review' : r.status}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'payouts' && (
          <Payouts user={currentUser} requests={payouts.filter(p => p.userId === currentUser.id)} onRequestPayout={handleRequestPayout} />
        )}

        {activeTab === 'admin' && currentUser.role === UserRole.ADMIN && (
          <AdminPanel 
            tasks={tasks} 
            reports={reports} 
            payouts={payouts} 
            users={allUsers}
            onAddTask={handleAddTask} 
            onVerifyReport={handleVerifyReport} 
            onManagePayout={handleManagePayout} 
          />
        )}
      </main>
    </div>
  );
};

export default App;
