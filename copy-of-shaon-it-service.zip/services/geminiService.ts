
import { GoogleGenAI, Type } from "@google/genai";

// Fix: Initializing GoogleGenAI using process.env.API_KEY directly as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateTaskDetails = async (title: string, category: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Create detailed professional work instructions for a team task titled "${title}" in the category "${category}". Provide a description and a list of 4-6 specific quality guidelines.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            description: { type: Type.STRING },
            guidelines: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            suggestedReward: { type: Type.NUMBER }
          },
          required: ["description", "guidelines", "suggestedReward"]
        }
      }
    });

    // Fix: Using the .text property directly (not calling it as a function)
    const jsonStr = response.text || '{}';
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Error generating task details:", error);
    return null;
  }
};

export const verifyReportWithAI = async (taskDescription: string, reportData: string, guidelines: string[]) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a work quality auditor. Compare this submitted work against the guidelines.
      
      Task: ${taskDescription}
      Guidelines: ${guidelines.join(', ')}
      Submitted Work: ${reportData}
      
      Provide a verification score (0-100) and brief feedback on quality and completeness.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            feedback: { type: Type.STRING },
            passed: { type: Type.BOOLEAN }
          },
          required: ["score", "feedback", "passed"]
        }
      }
    });

    // Fix: Using the .text property directly (not calling it as a function)
    const jsonStr = response.text || '{}';
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Error verifying report:", error);
    return { score: 0, feedback: "Error during automated verification.", passed: false };
  }
};