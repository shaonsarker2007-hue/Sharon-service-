
export enum UserRole {
  ADMIN = 'ADMIN',
  MEMBER = 'MEMBER'
}

export enum TaskStatus {
  OPEN = 'OPEN',
  PENDING_VERIFICATION = 'PENDING_VERIFICATION',
  COMPLETED = 'COMPLETED',
  REJECTED = 'REJECTED'
}

export enum PayoutStatus {
  PENDING = 'PENDING',
  PROCESSED = 'PROCESSED',
  CANCELLED = 'CANCELLED'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  avatar: string;
  balance: number; // In Taka
  totalEarned: number;
  joinedDate: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  rewardAmount: number; // In Taka
  status: TaskStatus;
  createdAt: string;
  guidelines: string[];
}

export interface Report {
  id: string;
  taskId: string;
  userId: string; // Linking to unique user
  taskTitle: string;
  submissionDate: string;
  workerName: string;
  workLink: string;
  visitCount: number;
  workDate: string;
  notes?: string;
  status: TaskStatus;
}

export interface PayoutRequest {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  requestDate: string;
  status: PayoutStatus;
  method: string;
  accountDetails: string;
}
